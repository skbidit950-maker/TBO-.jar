package dev.tbo;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.Options;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.Identifier;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.EntityHitResult;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.client.event.AddGuiOverlayLayersEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.listener.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

import java.util.*;

@Mod.EventBusSubscriber(modid = TBO.MOD_ID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.MOD)
public final class ClientFeatures {
    private static KeyMapping clickGuiKey;
    private static KeyMapping fullbrightKey;
    private static KeyMapping addWaypointKey;
    private static KeyMapping clearWaypointsKey;
    private static KeyMapping zoomKey;

    private static double previousGamma = 1.0;
    private static boolean capturedGamma;
    private static int previousFov = 70;
    private static boolean capturedFov;
    private static int previousCustomFov = 70;
    private static boolean capturedCustomFov;
    private static long lastScanTick;
    private static int clientTicks;
    private static int lastEatTick = -1000;

    private static final Map<Long, ChunkFinding> findings = new LinkedHashMap<>();
    private static final List<Waypoint> waypoints = new ArrayList<>();
    private static BlockPos targetedBlock;

    private ClientFeatures() {}

    @SubscribeEvent
    public static void registerKeys(RegisterKeyMappingsEvent event) {
        clickGuiKey = key("key.tbo.clickgui", GLFW.GLFW_KEY_RIGHT_SHIFT);
        fullbrightKey = key("key.tbo.fullbright", GLFW.GLFW_KEY_G);
        addWaypointKey = key("key.tbo.add_waypoint", GLFW.GLFW_KEY_K);
        clearWaypointsKey = key("key.tbo.clear_waypoints", GLFW.GLFW_KEY_L);
        zoomKey = key("key.tbo.zoom", GLFW.GLFW_KEY_Z);
        event.register(clickGuiKey);
        event.register(fullbrightKey);
        event.register(addWaypointKey);
        event.register(clearWaypointsKey);
        event.register(zoomKey);
    }

    @SubscribeEvent
    public static void registerGuiLayers(AddGuiOverlayLayersEvent event) {
        event.getLayeredDraw().add(
                Identifier.fromNamespaceAndPath(TBO.MOD_ID, "tbo_hud"),
                ClientFeatures::renderOverlay
        );
    }

    private static void renderOverlay(GuiGraphics gui, DeltaTracker deltaTracker) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) return;
        if (enabled("customcrosshair")) {
            int cx = mc.getWindow().getGuiScaledWidth() / 2;
            int cy = mc.getWindow().getGuiScaledHeight() / 2;
            int color = 0xEFFFFFFF;
            gui.fill(cx - 5, cy, cx - 2, cy + 1, color);
            gui.fill(cx + 2, cy, cx + 5, cy + 1, color);
            gui.fill(cx, cy - 5, cx + 1, cy - 2, color);
            gui.fill(cx, cy + 2, cx + 1, cy + 5, color);
        }
        int x = 8;
        int y = 8;

        // Lightweight local status overlays; these read client state only.
        if (enabled("performance")) {
            int fps = Minecraft.getInstance().getFps();
            String pingText = "Ping: n/a";
            if (mc.getConnection() != null && mc.player != null) {
                var info = mc.getConnection().getPlayerInfo(mc.player.getUUID());
                if (info != null) pingText = "Ping: " + info.getLatency() + " ms";
            }
            gui.drawString(mc.font, "FPS: " + fps + "  " + pingText, x, y,
                    0xFFB7E8FF, true);
            y += 12;
        }
        if (enabled("targethud") && mc.hitResult instanceof EntityHitResult entityHit
                && entityHit.getEntity() instanceof LivingEntity living) {
            String targetName = living.getDisplayName().getString();
            String targetHealth = String.format(java.util.Locale.ROOT, "%.1f / %.1f HP",
                    living.getHealth(), living.getMaxHealth());
            gui.drawString(mc.font, "Target: " + targetName + "  " + targetHealth,
                    x, y, 0xFFFFA6A6, true);
            y += 12;
        }
        if (enabled("nametags") && mc.hitResult instanceof EntityHitResult entityHit) {
            gui.drawString(mc.font, "Look: " + entityHit.getEntity().getName().getString(),
                    x, y, 0xFFE7D5FF, true);
            y += 12;
        }
        if (enabled("performance") && mc.player != null) {
            int armor = 0;
            int worn = 0;
            for (var stack : mc.player.getArmorSlots()) {
                if (!stack.isEmpty()) {
                    worn++;
                    int max = stack.getMaxDamage();
                    if (max > 0) armor += Math.max(0, 100 - (stack.getDamageValue() * 100 / max));
                }
            }
            if (worn > 0) {
                gui.drawString(mc.font, "Armor avg: " + (armor / worn) + "%",
                        x, y, 0xFFD5F0C8, true);
                y += 12;
            }
        }
        if (enabled("hud")) {
            gui.drawString(mc.font, "TBO", x, y, 0xFFFFFFFF, true);
            y += 12;
            gui.drawString(mc.font, "XYZ " + mc.player.blockPosition().getX() + " "
                    + mc.player.blockPosition().getY() + " " + mc.player.blockPosition().getZ(),
                    x, y, 0xFFE4EAF2, true);
            y += 12;
            gui.drawString(mc.font, "Dimension: " + mc.level.dimension().location(),
                    x, y, 0xFFE4EAF2, true);
            y += 12;
        }
        if (enabled("block_overlay") && targetedBlock != null) {
            BlockState state = mc.level.getBlockState(targetedBlock);
            String blockName = BuiltInRegistries.BLOCK.getKey(state.getBlock()).toString();
            gui.drawString(mc.font, blockName + " @ " + targetedBlock.getX() + ","
                    + targetedBlock.getY() + "," + targetedBlock.getZ(),
                    x, y, 0xFFFFD27A, true);
            y += 12;
        }
        if (enabled("light_debug") && targetedBlock != null) {
            int blockLight = mc.level.getBrightness(net.minecraft.world.level.LightLayer.BLOCK, targetedBlock);
            int skyLight = mc.level.getBrightness(net.minecraft.world.level.LightLayer.SKY, targetedBlock);
            gui.drawString(mc.font, "Light: block " + blockLight + " / sky " + skyLight,
                    x, y, 0xFFB7E8FF, true);
            y += 12;
        }
        if (enabled("waypoints")) {
            for (Waypoint waypoint : waypoints) {
                if (!waypoint.dimension.equals(mc.level.dimension())) continue;
                double distance = Math.sqrt(mc.player.distanceToSqr(
                        waypoint.x + 0.5, waypoint.y + 0.5, waypoint.z + 0.5));
                gui.drawString(mc.font, waypoint.name + " [" + (int) distance + "m] "
                        + waypoint.x + " " + waypoint.y + " " + waypoint.z,
                        x, y, 0xFF8FE6C0, true);
                y += 11;
            }
        }
        if (enabled("suschunkfinder") || enabled("base_finder")
                || enabled("motion_scanner") || enabled("storageesp")
                || enabled("spawnerfinder")) {
            int shown = 0;
            for (ChunkFinding finding : findings.values()) {
                if (shown++ >= 8) break;
                if (finding.dimension != mc.level.dimension()) continue;
                String label = "Chunk " + finding.x + "," + finding.z + " score " + finding.score;
                if (enabled("suschunkfinder") && finding.susScore > 0) {
                    gui.drawString(mc.font, "Sus: " + label, x, y, 0xFFFFC66D, true);
                    y += 11;
                } else if (enabled("base_finder") && finding.baseScore > 0) {
                    gui.drawString(mc.font, "Base clue: " + label, x, y, 0xFFB5A0FF, true);
                    y += 11;
                } else if (enabled("motion_scanner") && finding.lightScore > 0) {
                    gui.drawString(mc.font, "Light anomaly: " + label, x, y, 0xFF8EDFFF, true);
                    y += 11;
                }
            }
        }
        }

    private static KeyMapping key(String name, int code) {
        return new KeyMapping(name, InputConstants.Type.KEYSYM, code, "key.categories.tbo");
    }

    @Mod.EventBusSubscriber(modid = TBO.MOD_ID, value = Dist.CLIENT)
    public static final class ForgeEvents {
        @SubscribeEvent
        public static void clientTick(TickEvent.ClientTickEvent event) {
            if (event.phase != TickEvent.Phase.END) return;
            Minecraft mc = Minecraft.getInstance();
            if (mc.player == null || mc.level == null) return;
            clientTicks++;

            while (clickGuiKey.consumeClick()) mc.setScreen(new ClickGuiScreen());
            while (fullbrightKey.consumeClick()) {
                ModuleRegistry.byId("fullbright").ifPresent(ClientModule::toggle);
            }
            while (addWaypointKey.consumeClick()) addWaypoint();
            while (clearWaypointsKey.consumeClick()) {
                waypoints.clear();
                mc.player.displayClientMessage(Component.literal("TBO: waypoints cleared"), true);
            }
            while (zoomKey.consumeClick()) {
                ModuleRegistry.byId("zoom").ifPresent(ClientModule::toggle);
            }
            if (enabled("auto_sprint") && mc.screen == null && mc.options.keyUp.isDown()
                    && !mc.player.isCrouching() && !mc.player.isPassenger() && mc.player.getFoodData().getFoodLevel() > 6) {
                mc.player.setSprinting(true);
            }

            // AutoEat only uses food already held in either hand and invokes vanilla use-item.
            if (enabled("autoeat") && mc.screen == null && mc.gameMode != null
                    && mc.player.getFoodData().getFoodLevel() <= 16
                    && mc.player.canEat(false) && clientTicks - lastEatTick >= 20) {
                ItemStack main = mc.player.getMainHandItem();
                ItemStack off = mc.player.getOffhandItem();
                if (main.getFoodProperties(mc.player) != null) {
                    mc.gameMode.useItem(mc.player, InteractionHand.MAIN_HAND);
                    lastEatTick = clientTicks;
                } else if (off.getFoodProperties(mc.player) != null) {
                    mc.gameMode.useItem(mc.player, InteractionHand.OFF_HAND);
                    lastEatTick = clientTicks;
                }
            }

            // AutoTool chooses the fastest tool already in the hotbar for the targeted block.
            if (enabled("autotool") && mc.screen == null
                    && mc.hitResult instanceof net.minecraft.world.phys.BlockHitResult blockHit
                    && mc.gameMode != null) {
                BlockState state = mc.level.getBlockState(blockHit.getBlockPos());
                int bestSlot = mc.player.getInventory().getSelectedSlot();
                float bestSpeed = mc.player.getMainHandItem().getDestroySpeed(state);
                for (int slot = 0; slot < 9; slot++) {
                    ItemStack candidate = mc.player.getInventory().getItem(slot);
                    float speed = candidate.getDestroySpeed(state);
                    if (speed > bestSpeed) {
                        bestSpeed = speed;
                        bestSlot = slot;
                    }
                }
                mc.player.getInventory().setSelectedSlot(bestSlot);
            }

            if (clientTicks - lastScanTick >= 100) {
                lastScanTick = clientTicks;
                scanLoadedChunks(mc);
            }
            updateTargetedBlock(mc);
        }


    }

    private static boolean enabled(String id) {
        return ModuleRegistry.byId(id).map(ClientModule::enabled).orElse(false);
    }

    public static void onModuleChanged(ClientModule module) {
        if (module.id().equals("fullbright")) applyFullbright(module.enabled());
        if (module.id().equals("zoom")) applyZoom(module.enabled());
        if (module.id().equals("custom_fov")) applyCustomFov(module.enabled());
    }

    private static void applyZoom(boolean enabled) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.options == null) return;
        if (enabled) {
            if (!capturedFov) {
                previousFov = mc.options.fov().get();
                capturedFov = true;
            }
            mc.options.fov().set(30);
        } else if (capturedFov) {
            mc.options.fov().set(previousFov);
            capturedFov = false;
        }
    }

    private static void applyCustomFov(boolean enabled) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.options == null) return;
        if (enabled) {
            if (!capturedCustomFov) {
                previousCustomFov = mc.options.fov().get();
                capturedCustomFov = true;
            }
            mc.options.fov().set(100);
        } else if (capturedCustomFov) {
            mc.options.fov().set(previousCustomFov);
            capturedCustomFov = false;
        }
    }

    public static void applyFullbright(boolean enabled) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.options == null) return;
        Options options = mc.options;
        if (enabled) {
            if (!capturedGamma) {
                previousGamma = options.gamma().get();
                capturedGamma = true;
            }
            options.gamma().set(16.0);
        } else if (capturedGamma) {
            options.gamma().set(previousGamma);
            capturedGamma = false;
        }
    }

    private static void addWaypoint() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) return;
        BlockPos pos = mc.player.blockPosition();
        waypoints.add(new Waypoint("Waypoint " + (waypoints.size() + 1),
                pos.getX(), pos.getY(), pos.getZ(), mc.level.dimension()));
        mc.player.displayClientMessage(Component.literal("TBO: waypoint saved at "
                + pos.getX() + " " + pos.getY() + " " + pos.getZ()), true);
    }

    private static void updateTargetedBlock(Minecraft mc) {
        if (mc.hitResult instanceof net.minecraft.world.phys.BlockHitResult hit
                && hit.getType() == net.minecraft.world.phys.HitResult.Type.BLOCK) {
            targetedBlock = hit.getBlockPos();
        } else {
            targetedBlock = null;
        }
    }

    private static void scanLoadedChunks(Minecraft mc) {
        if (mc.level == null || mc.player == null) return;
        ChunkPos center = mc.player.chunkPosition();
        ResourceKey<Level> dimension = mc.level.dimension();
        int radius = 2;
        int minY = Math.max(mc.level.getMinBuildHeight(), mc.player.blockPosition().getY() - 32);
        int maxY = Math.min(mc.level.getMaxBuildHeight(), mc.player.blockPosition().getY() + 48);

        for (int cx = center.x - radius; cx <= center.x + radius; cx++) {
            for (int cz = center.z - radius; cz <= center.z + radius; cz++) {
                LevelChunk chunk = mc.level.getChunkSource().getChunk(cx, cz, net.minecraft.world.level.chunk.ChunkStatus.FULL, false);
                if (chunk == null) continue;
                int sus = 0;
                int base = 0;
                int light = 0;
                int storage = 0;
                int spawners = 0;

                for (int x = 0; x < 16; x++) {
                    for (int z = 0; z < 16; z++) {
                        for (int y = minY; y < maxY; y++) {
                            BlockPos pos = new BlockPos((cx << 4) + x, y, (cz << 4) + z);
                            Block block = chunk.getBlockState(pos).getBlock();

                            if (isGrowthClue(block)) sus++;
                            if (isBaseClue(block)) base++;
                            if (isStorage(block)) storage++;
                            if (block == Blocks.SPAWNER) spawners++;
                        }
                    }
                }
                if (sus > 0 || base > 0 || storage > 0 || spawners > 0) {
                    int lightScore = Math.max(0, storage - 1) + Math.max(0, sus / 3);
                    findings.put(chunkKey(cx, cz), new ChunkFinding(cx, cz, dimension,
                            sus, base, lightScore, storage, spawners));
                } else {
                    findings.remove(chunkKey(cx, cz));
                }
            }
        }
        while (findings.size() > 256) {
            Iterator<Long> it = findings.keySet().iterator();
            it.next();
            it.remove();
        }
    }

    private static boolean isGrowthClue(Block b) {
        return b == Blocks.AMETHYST_CLUSTER || b == Blocks.LARGE_AMETHYST_BUD
                || b == Blocks.MEDIUM_AMETHYST_BUD || b == Blocks.SMALL_AMETHYST_BUD
                || b == Blocks.BAMBOO || b == Blocks.KELP || b == Blocks.KELP_PLANT
                || b == Blocks.SWEET_BERRY_BUSH || b == Blocks.POINTED_DRIPSTONE
                || b == Blocks.CAVE_VINES || b == Blocks.CAVE_VINES_PLANT;
    }

    private static boolean isBaseClue(Block b) {
        return isStorage(b) || b == Blocks.CRAFTING_TABLE || b == Blocks.FURNACE
                || b == Blocks.BLAST_FURNACE || b == Blocks.SMOKER
                || b == Blocks.ANVIL || b == Blocks.ENCHANTING_TABLE
                || b == Blocks.BREWING_STAND || b == Blocks.BEACON
                || b == Blocks.RESPAWN_ANCHOR || b == Blocks.ENDER_CHEST;
    }

    private static boolean isStorage(Block b) {
        return b == Blocks.CHEST || b == Blocks.TRAPPED_CHEST || b == Blocks.BARREL
                || b == Blocks.SHULKER_BOX || b == Blocks.WHITE_SHULKER_BOX
                || b == Blocks.ORANGE_SHULKER_BOX || b == Blocks.MAGENTA_SHULKER_BOX
                || b == Blocks.LIGHT_BLUE_SHULKER_BOX || b == Blocks.YELLOW_SHULKER_BOX
                || b == Blocks.LIME_SHULKER_BOX || b == Blocks.PINK_SHULKER_BOX
                || b == Blocks.GRAY_SHULKER_BOX || b == Blocks.LIGHT_GRAY_SHULKER_BOX
                || b == Blocks.CYAN_SHULKER_BOX || b == Blocks.PURPLE_SHULKER_BOX
                || b == Blocks.BLUE_SHULKER_BOX || b == Blocks.BROWN_SHULKER_BOX
                || b == Blocks.GREEN_SHULKER_BOX || b == Blocks.RED_SHULKER_BOX
                || b == Blocks.BLACK_SHULKER_BOX;
    }

    private static long chunkKey(int x, int z) {
        return ((long) x << 32) ^ (z & 0xffffffffL);
    }

    private record ChunkFinding(int x, int z, ResourceKey<Level> dimension,
                                int susScore, int baseScore, int lightScore,
                                int storageCount, int spawnerCount) {
        int score() { return susScore + baseScore + storageCount * 2 + spawnerCount * 5; }
    }

    private record Waypoint(String name, int x, int y, int z, ResourceKey<Level> dimension) {}
}
