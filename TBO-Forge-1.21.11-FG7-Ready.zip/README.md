# TBO — Minecraft 1.21.11 / Forge 61.2.5

Independent client-side utility mod for Java 21.

## Build

The GitHub Actions workflow installs Gradle 9.6.0 and Java 21, then runs `gradle clean build` using ForgeGradle 7.0.29 or a compatible 7.x release. No Gradle installation or ZIP extraction step is needed in the workflow: the repository itself is the Gradle project.

To build locally, install JDK 21 and Gradle 9.6.0, then run:

```bash
gradle --no-daemon clean build
```

The output JAR is written to `build/libs/`.

## Target versions

- Minecraft: 1.21.11
- Forge: 61.2.5
- Java: 21
- ForgeGradle: 7.0.29+

## Implemented catalog entries

The existing Java source and module catalog are retained from the uploaded project. The build configuration is migrated from ForgeGradle 6 to the current ForgeGradle 7 MDK style.

## Important validation note

The previous CI failure (`duplicate entry: mcp/client/Start.class`) occurred during ForgeGradle 6 mapped-artifact generation. This project now uses ForgeGradle 7, whose API and dependency setup differ from ForgeGradle 6. The ZIP structure and configuration have been updated, but a successful remote GitHub Actions run is still required to verify the source against Forge 61.2.5.
