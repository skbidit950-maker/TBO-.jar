package dev.tbo;

import net.minecraftforge.fml.loading.FMLPaths;
import java.io.*;
import java.nio.file.*;
import java.util.Properties;

public final class ClientConfig {
    private static final Path FILE = FMLPaths.CONFIGDIR.get().resolve("tbo.properties");
    private ClientConfig() {}

    public static void load() {
        if (!Files.exists(FILE)) return;
        Properties p = new Properties();
        try (Reader r = Files.newBufferedReader(FILE)) {
            p.load(r);
            for (ClientModule module : ModuleRegistry.all()) {
                if (module.implemented()) {
                    module.setEnabled(Boolean.parseBoolean(p.getProperty("module." + module.id(), "false")));
                }
            }
        } catch (IOException e) {
            System.err.println("[TBO] Config load failed: " + e.getMessage());
        }
    }

    public static void save() {
        Properties p = new Properties();
        for (ClientModule module : ModuleRegistry.all()) {
            if (module.implemented()) p.setProperty("module." + module.id(), Boolean.toString(module.enabled()));
        }
        try {
            Files.createDirectories(FILE.getParent());
            try (Writer w = Files.newBufferedWriter(FILE)) {
                p.store(w, "TBO settings");
            }
        } catch (IOException e) {
            System.err.println("[TBO] Config save failed: " + e.getMessage());
        }
    }
}
