package dev.tbo;

import net.minecraftforge.fml.common.Mod;

@Mod(TBO.MOD_ID)
public final class TBO {
    public static final String MOD_ID = "tbo";

    public TBO() {
        ModuleRegistry.loadCatalog();
        ClientConfig.load();
    }
}
